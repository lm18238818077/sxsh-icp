1、修改Install.bat，将sdkserver的IP地址替换为实际的地址。
    set sdkserver=10.120.224.229 sdkserver.cloudicp.huawei.com
2、以管理员权限执行install.bat
3、可以查看install.log检查是否成功
4、对于hosts文件，脚本只判断sdkserver.cloudicp.huawei.com和localhost.cloudicp.huawei.com是否存在。如果域名不存在，则添加。如果域名已经存在，则不会更新对应的IP地址。如果之前已经配置了hosts，当sdkserver的地址发生变化，使用此脚本无法更新IP。需要手工编辑hosts文件。